<!-- login section -->
<div class="contact left_cross_right">
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <div class="titlepage text_align_left">
          <h2>Login</h2>
          <p>Access your account.</p>
        </div>
      </div>
      <div class="col-md-12">
        <form id="login" class="main_form">
          <div class="row">
            <div class="col-md-12">
              <input class="contactus" placeholder="Email" type="email" name="email">
            </div>
            <div class="col-md-12">
              <input class="contactus" placeholder="Password" type="password" name="password">
            </div>
            <div class="col-md-12">
              <button class="send_btn">Login</button>
            </div>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>
<!-- end login section -->