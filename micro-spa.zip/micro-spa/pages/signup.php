<!-- signup section -->
<div class="contact left_cross_right">
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <div class="titlepage text_align_left">
          <h2>Signup</h2>
          <p>Create an account to access exclusive features.</p>
        </div>
      </div>
      <div class="col-md-12">
        <form id="signup" class="main_form" action="#">
          <div class="row">
          <div class="col-md-12">
              <input class="contactus" placeholder="Username" type="text" name="username">
            </div>
            <div class="col-md-12">
              <input class="contactus" placeholder="Email" type="email" name="email">
            </div>
            <div class="col-md-6">
              <input class="contactus" placeholder="First Name" type="text" name="first_name">
            </div>
            <div class="col-md-6">
              <input class="contactus" placeholder="Last Name" type="text" name="last_name">
            </div>           
            <div class="col-md-12">
              <input class="contactus" placeholder="Password" type="password" name="password">
            </div>
            <div class="col-md-12">
              <input class="contactus" placeholder="Confirm Password" type="password" name="confirm_password">
            </div>
            <div class="col-md-12">
              <button class="send_btn">Register</button>
            </div>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>
<!-- end register section -->