<!-- start slider section -->
<div id="top_section" class=" banner_main">
         <div class="container">
            <div class="row d_flex">
               <div class="col-md-6">
                  <div class="airmic">
                     <h1>404 Error </h1>
                     <p>The page you are trying to access either doesn't exist or access to the page may be restricted.</p>
                     <a class="read_more" href="Javascript:void(0)" data-page="home" >Back Home</a>
                  </div>
               </div>
               
            </div>
         </div>
      </div>
      <!-- end contact section -->