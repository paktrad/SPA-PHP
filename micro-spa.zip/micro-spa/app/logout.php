<!-- start slider section -->
<div id="top_section" class=" banner_main">
         <div class="container">
            <div class="row d_flex">
               <div class="col-md-6">
                  <div class="airmic">
                     <h1>Logout</h1>
                     <p>Are you sure you want to logout</p>
                     <a class="read_more" href="Javascript:void(0)" data-page="home" >Logout</a>
                  </div>
               </div>
               
            </div>
         </div>
      </div>
      <!-- end contact section -->