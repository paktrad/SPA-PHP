<?php
session_start();

$_SESSION['user_logged_in'] = false;
$is_authenticated = $_SESSION['user_logged_in'];

// Define allowed pages based on authentication
if ($is_authenticated) {
    $allowed_pages = ['home', 'about', 'contact', 'services', 'shop', 'dashboard', 'settings', 'logout', '404' ];
} else {
    $allowed_pages = ['home', 'about', 'services', 'shop', 'contact', 'signup', 'login', '404' ];
}

// Determine the requested page, default to home
$requested_page = $_GET['page'] ?? 'home';

// Checks to grant access to dashborad and auth pages
if ($requested_page == 'dashboard' && !$is_authenticated) {
    echo json_encode(['redirect' => '?page=login']);
    exit;
} elseif (in_array($requested_page, ['login', 'signup']) && $is_authenticated) {
    echo json_encode(['redirect' => '?page=dashboard']);
    exit;
}

// Check if requested page is in the allowed list else fire error
if (!in_array($requested_page, $allowed_pages)) {
    echo json_encode(['error' => 'Access Restricted.', 'redirect' => '?page=404']);
    exit;
}


// Validating and assigning routes to pages
$page_path = match ($requested_page) {
    'home' => './pages/home.php',
    'about' => './pages/about.php',
    'shop' => './pages/shop.php',
    'services' => './pages/services.php',   
    'contact' => './pages/contact.php',
    'signup' => './pages/signup.php',
    'login' => './pages/login.php',
    'dashboard' => './app/app/dashboard.php',  
    'settings' => './app/app/settings.php',   
    'logout' => './app/logout.php',
    default => '404.php'
};

// Return the page content dynamically
if (file_exists($page_path)) {
    ob_start();
    include $page_path;
    $content = ob_get_clean();
    echo json_encode(['content' => $content, 'authenticated' => $is_authenticated]);
} else {
    echo json_encode(['error' => 'Page not found']);
}
exit;

?>