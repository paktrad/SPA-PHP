<!DOCTYPE html>
<html lang="en">
   <head>
      <!-- basic -->
      <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <!-- mobile metas -->
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <meta name="viewport" content="initial-scale=1, maximum-scale=1">
      <!-- site metas -->
      <title>SPA:PHP</title>
      <meta name="keywords" content="">
      <meta name="description" content="">
      <meta name="author" content="">
      <!-- bootstrap css -->
      <link rel="stylesheet" href="css/bootstrap.min.css">
      <!-- style css -->
      <link rel="stylesheet" href="css/style.css">
      <!-- responsive-->
      <link rel="stylesheet" href="css/responsive.css">
      <!-- awesome fontfamily -->
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
      <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script><![endif]-->
   </head>
   <!-- body -->
   <body>
      <!-- loader  -->
      <div class="loader_bg">
         <div class="loader"><img src="images/loading.gif" alt="" /></div>
      </div>
      <!-- end loader -->
      <div id="mySidepanel" class="sidepanel">
         <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">×</a>
         <a class="active" href="#" data-page="home">Home</a>
         <a href="#" data-page="about">About</a>
         <a href="#" data-page="services">Searvices</a>
         <a href="#" data-page="shop">Shop</a>
         <a href="#" data-page="contact">Contact</a>
         <a href="#" data-page="signup" class="unauthenticated-menu">signup</a>
         <a href="#" data-page="login" class="unauthenticated-menu">Login</a>
         <a href="#" data-page="dashboard" class="authenticated-menu">Dashboard</a>
         <a href="#" data-page="logout" class="authenticated-menu">Logout</a>
      </div>
      <!-- header -->
      <header>
         <!-- header inner -->
         <div class="head-top">
            <div class="container-fluid">
               <div class="row d_flex">
                  <div class="col-sm-3">
                     <div class="logo">
                        <a href="" data-page="home"><img src="images/logo.png" /></a>
                     </div>
                  </div>
                  <div class="col-sm-9">
                     <ul class="email text_align_right">
                        <li class="d_none"> <a href="javascript:void(0)" data-page="login" class="unauthenticated-menu"><i class="fa fa-user" aria-hidden="true"></i>
                           Login</a>
                        </li>
                        <li> <button class="openbtn" onclick="openNav()"><img src="images/menu_btn.png"></button></li>
                     </ul>
                  </div>
               </div>
            </div>
         </div>
      </header>

<div id="dynamic-content">

</div>



      <footer>
         <div class="footer">
            <div class="container">
               <div class="row">
                  <div class="col-md-12">
                     <a class="logo_footer"><img src="images/logo.png" alt="#"/></a>
                  </div>
                  <div class="col-md-5">
                     <div class="Informa conta">
                        <h3>Adderess</h3>
                        <ul>
                           <li> Jobify Inc Canada. 545 Younge St, <br>Suite 11 Toronto, Ontario M4K 6F4
                           </li>
                        </ul>
                     </div>
                     <div class="Informa helpful">
                        <ul>
                           <li><a href="#" data-page="home">Home</a></li>
                           <li><a href="#" data-page="about">About</a></li>
                           <li><a href="#" data-page="services">Services</a></li>
                           <li><a href="#" data-page="shop">Shop</a></li>
                           <li><a href="#" data-page="contact">Contact</a></li>
                        </ul>
                     </div>
                  </div>
                  <div class="col-md-4">
                     <div class="Informa conta">
                        <h3>Contact Us</h3>
                        <ul>
                           <li> <a href="Javascript:void(0)"> (+92) 303 4331955
                              </a>
                           </li>
                           <li> <a href="Javascript:void(0)">  info@webpub.pk
                              </a>
                           </li>
                        </ul>
                     </div>
                     <ul class="social_icon text_align_center">
                        <li> <a href="Javascript:void(0)"><i class="fa fa-facebook-f"></i></a></li>
                        <li> <a href="Javascript:void(0)"><i class="fa fa-twitter"></i></a></li>
                        <li> <a href="Javascript:void(0)"><i class="fa fa-instagram" aria-hidden="true"></i></a></li>
                     </ul>
                  </div>
                  <div class="col-md-3">
                     <div class="Informa">
                        <h3>Newsletter</h3>
                        <form class="newslatter_form">
                           <input class="ente" placeholder="Enter your email" type="text" name="Enter your email">
                           <button class="subs_btn">Subscribe</button>
                        </form>
                     </div>
                  </div>
               </div>
            </div>
            <div class="copyright text_align_center">
               <div class="container">
                  <div class="row">
                     <div class="col-md-10 offset-md-1">
                        <p>© <?=date('Y');?> <a href="https://webpub.pk/">Webpub.pk</a> All Rights Reserved. Design by  <a href="https://html.design/"> Free Html Template</a></p>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </footer>
      <!-- end footer -->
      <!-- Javascript files-->
      <script src="js/jquery.min.js"></script>
      <script src="js/bootstrap.bundle.min.js"></script>
      <script src="js/jquery-3.0.0.min.js"></script>
      <script src="js/custom.js"></script>
      <script>
$(document).ready(function() {
    function loadPage(page) {
        $.ajax({
            url: 'routes.php',
            type: 'GET',
            data: { page: page },
            dataType: 'json',
            success: function (response) {
                if (response.redirect) {
                    // Handle redirection if needed
                    loadPage(response.redirect.split('=')[1]);
                } else if (response.content) {
                    // Update the main content area
                    $('#dynamic-content').html(response.content);

                    // Update URL for better UX without page reload
                    history.pushState(null, '', '?page=' + page);

                   // Update menu visibility based on authentication status
                   updateMenu(response.authenticated); // Pass the authenticated value here

                    // Update body class based on the page
                    updateBodyClass(page); // Call the function here
                } else if (response.error) {
                    alert(response.error);
                    if (response.redirect) {
                    // Handle redirection if needed
                    loadPage(response.redirect.split('=')[1]);
                }
                    
                }
            },
            error: function () {
                alert('An error occurred while loading the page.');
            }
        });
    }

    // Function to update body class based on the loaded page
    function updateBodyClass(page) {
        if (page === 'home') {
            $('body').attr('class', 'main-layout'); // Set a specific class for the home page
        } else {
            $('body').attr('class', 'main-layout inner_page'); // Assign class dynamically based on page
        }
    }

    function updateMenu(isAuthenticated) {
        if (isAuthenticated) {
            // User is authenticated: Show authenticated menu items
            $('.authenticated-menu').show();
            $('.unauthenticated-menu').hide();
        } else {
            // User is not authenticated: Show unauthenticated menu items
            $('.authenticated-menu').hide();
            $('.unauthenticated-menu').show();
        }
    }


    // Attach event listener to all navigation links dynamically
    $('body').on('click', 'a[data-page]', function (e) {
        e.preventDefault();
        const page = $(this).data('page');
        loadPage(page);
    });

    // Load the initial page based on the URL or default to 'home'
    const urlParams = new URLSearchParams(window.location.search);
    const initialPage = urlParams.get('page') || 'home';
    loadPage(initialPage);

    // Handle browser back/forward navigation
    window.onpopstate = function(event) {
        const page = urlParams.get('page') || 'home';
        loadPage(page);
    };
});
</script>

   </body>
</html>

