<!-- our_mics -->
<div class="our_mics">
         <div class="container">
            <div class="row">
               <div class="col-md-10 offset-md-1">
                  <div class="titlepage text_align_center">
                     <h2>Our Shop</h2>
                     <p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable. If you</p>
                  </div>
               </div>
            </div>
            <div class="row">
               <div class="col-md-4 col-sm-6 margin_bottom40">
                  <div id="ho_show" class="mics">
                     <figure><img class="img_responsive" src="images/mics_img1.jpg" alt="#"/></figure>
                     <div class="mics_icon">
                        <a href="javascript:void(0)">
                        <i class="fa fa-search" aria-hidden="true"></i>
                        </a>
                     </div>
                  </div>
               </div>
               <div class="col-md-4 col-sm-6 margin_bottom40">
                  <div id="ho_show" class="mics">
                     <figure><img class="img_responsive" src="images/mics_img2.jpg" alt="#"/></figure>
                     <div class="mics_icon">
                        <a href="javascript:void(0)">
                        <i class="fa fa-search" aria-hidden="true"></i>
                        </a>
                     </div>
                  </div>
               </div>
               <div class="col-md-4 col-sm-6 margin_bottom40">
                  <div id="ho_show" class="mics">
                     <figure><img class="img_responsive" src="images/mics_img3.jpg" alt="#"/></figure>
                     <div class="mics_icon">
                        <a href="javascript:void(0)">
                        <i class="fa fa-search" aria-hidden="true"></i>
                        </a>
                     </div>
                  </div>
               </div>
               <div class="col-md-4 col-sm-6 margin_bottom40">
                  <div id="ho_show" class="mics">
                     <figure><img class="img_responsive" src="images/mics_img4.jpg" alt="#"/></figure>
                     <div class="mics_icon">
                        <a href="javascript:void(0)">
                        <i class="fa fa-search" aria-hidden="true"></i>
                        </a>
                     </div>
                  </div>
               </div>
               <div class="col-md-4 col-sm-6 margin_bottom40">
                  <div id="ho_show" class="mics">
                     <figure><img class="img_responsive" src="images/mics_img5.jpg" alt="#"/></figure>
                     <div class="mics_icon">
                        <a href="javascript:void(0)">
                        <i class="fa fa-search" aria-hidden="true"></i>
                        </a>
                     </div>
                  </div>
               </div>
               <div class="col-md-4 col-sm-6 margin_bottom40">
                  <div id="ho_show" class="mics">
                     <figure><img class="img_responsive" src="images/mics_img6.jpg" alt="#"/></figure>
                     <div class="mics_icon">
                        <a href="javascript:void(0)">
                        <i class="fa fa-search" aria-hidden="true"></i>
                        </a>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <!-- end our_mics -->