<!-- start slider section -->
<div id="top_section" class=" banner_main">
         <div class="container">
            <div class="row d_flex">
               <div class="col-md-6">
                  <div class="airmic">
                     <h1>User Settings </h1>
                     <p>You can develop this page as you like!</p>
                     <a class="read_more" href="Javascript:void(0)" data-page="dashboard" >your Dashboard</a>
                  </div>
               </div>
               
            </div>
         </div>
      </div>
      <!-- end contact section -->